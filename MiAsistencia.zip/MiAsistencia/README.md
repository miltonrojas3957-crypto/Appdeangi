# Mi Asistencia 🌷🦕

App Android nativa (Kotlin + Jetpack Compose + Room) para registrar tu asistencia
laboral diaria con un simple V (trabajé) / X (no trabajé), con estética
"cute productivity" en pastel.

## Cómo abrir el proyecto

1. Abre **Android Studio** (versión Koala/2024.1 o más reciente recomendado).
2. `File → Open` y selecciona la carpeta `MiAsistencia/` (esta carpeta).
3. Deja que Android Studio sincronice Gradle (descargará las dependencias la
   primera vez; necesita conexión a internet para `google()` y `mavenCentral()`).
4. Ejecuta en un emulador o dispositivo con **Android 8.0 (API 26) o superior**.

No se incluye el `.jar` del Gradle Wrapper binario (no se puede generar en el
entorno donde se creó este proyecto). Android Studio te ofrecerá regenerarlo
automáticamente al abrir el proyecto, o puedes ejecutar `gradle wrapper` una
vez si tienes Gradle instalado localmente.

## Obtener un APK instalable sin Android Studio

Incluí `.github/workflows/build-apk.yml`, un flujo de **GitHub Actions** que
compila el APK de debug en la nube (los runners de GitHub sí tienen acceso
completo al SDK de Android y a Gradle):

1. Crea un repositorio en GitHub y sube esta carpeta (`git init`, `git add .`,
   `git commit`, `git push` a un repo nuevo).
2. En GitHub, pestaña **Actions** → selecciona "Build APK" → **Run workflow**
   (o simplemente espera: se dispara solo con cada `push`).
3. Cuando termine (~3-5 min), entra a esa ejecución y descarga el artefacto
   **MiAsistencia-debug-apk** en la sección "Artifacts". Es un `.zip` que
   contiene el `app-debug.apk`.
4. Pasa el APK a tu teléfono e instálalo (activa "Instalar apps de orígenes
   desconocidos" si Android lo pide). Al ser un APK de debug no necesita
   firma adicional para instalarse en tu propio dispositivo.

## Qué incluye

- **Registro rápido** V/X en la pantalla principal, con confirmación antes de
  sobrescribir un registro existente.
- **Calendario mensual** con celdas de colores pastel por estado y detalle de
  cada día (cambiar a V/X, eliminar).
- **Estadísticas del período** (trabajados, no asistidos, sin registrar,
  porcentaje de asistencia) recalculadas automáticamente.
- **Dos modos de período**: mes calendario o ciclo personalizado desde el
  primer registro (configurable en Ajustes).
- **Historial** de períodos anteriores con filtros por año, mes y estado.
- **Recordatorios** configurables (hora, días, segundo recordatorio) con
  botones "SÍ" / "NO" directamente desde la notificación, usando
  `AlarmManager` + `BroadcastReceiver` (persisten tras reiniciar el teléfono).
- **Dos widgets** de pantalla de inicio (compacto y grande) que registran V/X
  sin abrir la app, vía `RemoteViews` + `BroadcastReceiver`.
- **Exportación/importación** CSV y JSON, y **copia de seguridad** completa en
  un único archivo JSON (registros + configuración), todo mediante el
  selector de archivos del sistema (sin pedir permisos de almacenamiento).
- **100% offline**: Room/SQLite local, sin cuentas ni servidores.
- **Tema claro/oscuro** con paleta pastel propia (nunca negro puro en oscuro).
- **Personalización visual** con 5 estilos seleccionables desde Ajustes.

## Decisiones de diseño (y qué falta pulir)

- **Decoraciones (flores, nubes, dino chubby)**: se implementaron como
  "stickers" con emoji (🦕🌷☁️✨) sobre fondos circulares pastel
  (`ui/components/Decorations.kt`), igual que en los mockups de la
  especificación original. Es una solución robusta y coherente, pero si
  quieres ilustraciones más elaboradas (un dino con distintas poses, flores
  creciendo animadas, etc.) lo ideal es reemplazarlas por assets vectoriales
  o Lottie — dejé el punto de extensión listo en ese mismo archivo.
- **Tipografía**: usa la fuente del sistema. Para un look aún más "cute" se
  puede añadir una fuente redondeada (p. ej. Baloo 2 o Quicksand) como
  recurso en `res/font` y referenciarla en `ui/theme/Type.kt`.
- **Configuración del widget**: en vez de una `AppWidgetConfigureActivity`
  aparte, el widget lee las preferencias generales guardadas en Ajustes →
  Widget. Es más simple y cumple el requisito de ser configurable.
- **Textos**: por rapidez, la mayoría de los textos están escritos
  directamente en los Composables en español, en vez de extraídos a
  `strings.xml`. Fácil de mover si luego quieres soportar varios idiomas.
- **No se pudo compilar/ejecutar** el proyecto en el entorno donde se generó
  (no tiene acceso al SDK de Android ni al repositorio Maven de Google), así
  que el código fue revisado cuidadosamente a mano pero **no probado en un
  compilador real**. Es muy probable que compile tal cual, pero al abrirlo en
  Android Studio revisa los errores marcados en rojo (si los hay, suelen ser
  detalles menores de imports o versiones de librerías) antes de dar por
  terminado el trabajo.

## Estructura del código

```
app/src/main/java/com/atundeajo/miasistencia/
├── data/            Room (entidad, DAO, DB), DataStore de preferencias,
│                    export/import CSV-JSON, copia de seguridad
├── domain/          Fechas, cálculo de períodos y estadísticas (sin Android)
├── ui/
│   ├── theme/       Colores pastel, tipografía, formas, tokens
│   ├── components/  Piezas reutilizables (celda de día, tarjetas, diálogos)
│   ├── home/        Pantalla principal + ViewModel
│   ├── calendar/    Calendario + detalle de día + ViewModel
│   ├── history/     Historial de períodos + ViewModel
│   ├── settings/    Ajustes + ViewModel
│   ├── personalization/  Selector de estilo visual
│   └── navigation/  NavHost + barra inferior
├── notifications/   Canal, AlarmManager, recibir acciones de notificación
└── widget/          Dos AppWidgetProvider (compacto y grande) + acciones
```

## Próximos pasos sugeridos

- Probar la compilación real en Android Studio y corregir cualquier detalle
  de versión de librería que el IDE señale.
- Reemplazar los emoji decorativos por ilustraciones propias si quieres un
  estilo más distintivo.
- Añadir tests unitarios para `PeriodCalculator` y `StatsCalculator` (son
  puro Kotlin, sin dependencias de Android, así que son fáciles de testear).
