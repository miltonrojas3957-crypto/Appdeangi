# Reglas por defecto de Android Studio; agrega reglas específicas del proyecto aquí si activas minify.
