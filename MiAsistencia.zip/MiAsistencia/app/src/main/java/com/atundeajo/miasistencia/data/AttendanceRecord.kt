package com.atundeajo.miasistencia.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Un registro de asistencia para un día concreto.
 * Un día sin fila en esta tabla se interpreta como "sin registrar".
 */
@Entity(
    tableName = "attendance_records",
    indices = [Index(value = ["fecha"], unique = true)]
)
data class AttendanceRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val fecha: String,          // ISO-8601 yyyy-MM-dd
    val diaSemana: String,      // "Lunes", "Martes", ...
    val estado: String,         // "V" (asistió) o "X" (no asistió)
    val horaRegistro: String,   // HH:mm
    val fechaHoraTimestamp: Long, // epoch millis del momento del registro
    val periodoId: String       // id del período al que pertenece, ver PeriodCalculator
) {
    companion object {
        const val ESTADO_V = "V"
        const val ESTADO_X = "X"
    }
}
