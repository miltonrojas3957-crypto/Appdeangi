package com.atundeajo.miasistencia.domain

import com.atundeajo.miasistencia.data.AttendanceRecord
import java.time.temporal.ChronoUnit

data class PeriodStats(
    val trabajados: Int,
    val noAsistidos: Int,
    val sinRegistrar: Int,
    val totalDias: Int,
    val porcentaje: Double
)

object StatsCalculator {
    fun calcular(range: PeriodRange, records: List<AttendanceRecord>): PeriodStats {
        val totalDias = (ChronoUnit.DAYS.between(range.start, range.end).toInt() + 1)
            .coerceAtLeast(0)
        val trabajados = records.count { it.estado == AttendanceRecord.ESTADO_V }
        val noAsistidos = records.count { it.estado == AttendanceRecord.ESTADO_X }
        val sinRegistrar = (totalDias - trabajados - noAsistidos).coerceAtLeast(0)
        val base = trabajados + noAsistidos
        val porcentaje = if (base > 0) (trabajados.toDouble() / base) * 100.0 else 0.0
        return PeriodStats(trabajados, noAsistidos, sinRegistrar, totalDias, porcentaje)
    }
}
