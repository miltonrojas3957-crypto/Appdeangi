package com.atundeajo.miasistencia.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.atundeajo.miasistencia.ui.calendar.CalendarScreen
import com.atundeajo.miasistencia.ui.history.HistoryScreen
import com.atundeajo.miasistencia.ui.home.HomeScreen
import com.atundeajo.miasistencia.ui.personalization.PersonalizationScreen
import com.atundeajo.miasistencia.ui.settings.SettingsScreen

private object Rutas {
    const val HOME = "home"
    const val CALENDAR = "calendar"
    const val HISTORY = "history"
    const val SETTINGS = "settings"
    const val PERSONALIZATION = "personalization"
}

private data class BottomItem(val route: String, val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

private val bottomItems = listOf(
    BottomItem(Rutas.HOME, "Inicio", Icons.Default.Home),
    BottomItem(Rutas.CALENDAR, "Calendario", Icons.Default.CalendarMonth),
    BottomItem(Rutas.HISTORY, "Historial", Icons.Default.List),
    BottomItem(Rutas.SETTINGS, "Ajustes", Icons.Default.Settings)
)

@Composable
fun MiAsistenciaNavGraph() {
    val navController = rememberNavController()

    Scaffold(
        bottomBar = {
            val backStackEntry by navController.currentBackStackEntryAsState()
            val currentRoute = backStackEntry?.destination
            NavigationBar {
                bottomItems.forEach { item ->
                    NavigationBarItem(
                        selected = currentRoute?.hierarchy?.any { it.route == item.route } == true,
                        onClick = {
                            navController.navigate(item.route) {
                                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(item.icon, contentDescription = item.label) },
                        label = { Text(item.label) }
                    )
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Rutas.HOME,
            modifier = Modifier.padding(padding)
        ) {
            composable(Rutas.HOME) { HomeScreen() }
            composable(Rutas.CALENDAR) { CalendarScreen() }
            composable(Rutas.HISTORY) { HistoryScreen() }
            composable(Rutas.SETTINGS) {
                SettingsScreen(onAbrirPersonalizacion = { navController.navigate(Rutas.PERSONALIZATION) })
            }
            composable(Rutas.PERSONALIZATION) { PersonalizationScreen() }
        }
    }
}
