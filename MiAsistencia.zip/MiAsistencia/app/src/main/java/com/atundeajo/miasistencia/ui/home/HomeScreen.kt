package com.atundeajo.miasistencia.ui.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.runtime.collectAsState
import com.atundeajo.miasistencia.data.AttendanceRecord
import com.atundeajo.miasistencia.domain.DateUtils
import com.atundeajo.miasistencia.ui.components.ConfirmDialog
import com.atundeajo.miasistencia.ui.components.EmojiBadge
import com.atundeajo.miasistencia.ui.components.Emojis
import com.atundeajo.miasistencia.ui.components.StatsSummaryCard
import java.time.LocalTime

@Composable
fun HomeScreen(viewModel: HomeViewModel = viewModel()) {
    val settings by viewModel.settings.collectAsState()
    val todayRecord by viewModel.todayRecord.collectAsState()
    val periodStats by viewModel.periodStats.collectAsState()
    val pendingConfirm by viewModel.pendingConfirmEstado.collectAsState()
    val hoy = viewModel.hoy()

    val saludo = DateUtils.saludoSegunHora(LocalTime.now().hour)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
    ) {
        Text("$saludo ${Emojis.FLOR}", style = MaterialTheme.typography.headlineMedium)
        Text(DateUtils.formatoFechaLarga(hoy), style = MaterialTheme.typography.bodyLarge)

        Column(modifier = Modifier.padding(top = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                EmojiBadge(emoji = Emojis.DINO, size = 96.dp, emojiSize = 52.dp)
            }

            androidx.compose.foundation.layout.Spacer(modifier = Modifier.height(20.dp))

            Text(
                when (todayRecord?.estado) {
                    AttendanceRecord.ESTADO_V -> "¡Registrado! Hoy trabajaste ${Emojis.FLOR}"
                    AttendanceRecord.ESTADO_X -> "Día registrado."
                    else -> "¿Trabajaste hoy?"
                },
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.SemiBold
            )

            if (todayRecord != null) {
                Text(
                    "Registrado a las ${todayRecord!!.horaRegistro}",
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            androidx.compose.foundation.layout.Spacer(modifier = Modifier.height(16.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(
                    onClick = { viewModel.onQuickRegister(AttendanceRecord.ESTADO_V) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.tertiary
                    ),
                    shape = MaterialTheme.shapes.large
                ) {
                    Text("${Emojis.CHECK} SÍ, TRABAJÉ")
                }
                OutlinedButton(
                    onClick = { viewModel.onQuickRegister(AttendanceRecord.ESTADO_X) },
                    shape = MaterialTheme.shapes.large
                ) {
                    Text("${Emojis.CRUZ} NO TRABAJÉ")
                }
            }
        }

        androidx.compose.foundation.layout.Spacer(modifier = Modifier.height(28.dp))

        StatsSummaryCard(stats = periodStats)
    }

    if (pendingConfirm != null) {
        val existingEstado = todayRecord?.estado
        val nombreExistente = if (existingEstado == AttendanceRecord.ESTADO_V) "Asistió" else "No asistió"
        ConfirmDialog(
            titulo = "Ya existe un registro para hoy",
            mensaje = "$nombreExistente, registrado a las ${todayRecord?.horaRegistro}. ¿Deseas cambiarlo?",
            onConfirm = { viewModel.confirmRegister(pendingConfirm!!) },
            onDismiss = { viewModel.cancelConfirm() }
        )
    }
}

@Preview
@Composable
private fun HomeScreenPreview() {
    // Vista previa básica; requiere un contexto de Application real para el ViewModel.
}
