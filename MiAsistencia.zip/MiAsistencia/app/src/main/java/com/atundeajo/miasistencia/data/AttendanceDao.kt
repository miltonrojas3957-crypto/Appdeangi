package com.atundeajo.miasistencia.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface AttendanceDao {

    @Query("SELECT * FROM attendance_records WHERE fecha = :fecha LIMIT 1")
    suspend fun getByDate(fecha: String): AttendanceRecord?

    @Query("SELECT * FROM attendance_records ORDER BY fecha ASC")
    fun observeAll(): Flow<List<AttendanceRecord>>

    @Query("SELECT * FROM attendance_records ORDER BY fecha ASC")
    suspend fun getAllOnce(): List<AttendanceRecord>

    @Query("SELECT * FROM attendance_records WHERE fecha BETWEEN :start AND :end ORDER BY fecha ASC")
    fun observeRange(start: String, end: String): Flow<List<AttendanceRecord>>

    @Query("SELECT * FROM attendance_records WHERE fecha BETWEEN :start AND :end ORDER BY fecha ASC")
    suspend fun getRange(start: String, end: String): List<AttendanceRecord>

    @Query("SELECT MIN(fecha) FROM attendance_records")
    suspend fun getFirstRecordDate(): String?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(record: AttendanceRecord)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(records: List<AttendanceRecord>)

    @Query("DELETE FROM attendance_records WHERE fecha = :fecha")
    suspend fun deleteByDate(fecha: String)

    @Query("DELETE FROM attendance_records")
    suspend fun deleteAll()
}
