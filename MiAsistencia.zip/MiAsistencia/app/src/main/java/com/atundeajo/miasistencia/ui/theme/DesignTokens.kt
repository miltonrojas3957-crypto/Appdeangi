package com.atundeajo.miasistencia.ui.theme

import androidx.compose.ui.unit.dp

/** Tokens de espaciado y elevación centralizados para mantener consistencia visual. */
object Spacing {
    val xs = 4.dp
    val sm = 8.dp
    val md = 16.dp
    val lg = 24.dp
    val xl = 32.dp
}

object Elevation {
    val card = 2.dp
    val raised = 6.dp
}
