package com.atundeajo.miasistencia.data

import com.atundeajo.miasistencia.domain.DateUtils
import org.json.JSONArray
import org.json.JSONObject
import java.io.InputStream
import java.io.OutputStream
import java.time.format.DateTimeFormatter

/**
 * Exporta e importa registros en CSV y JSON.
 * Trabaja sobre Streams para poder usarse junto al Storage Access Framework
 * (ActivityResultContracts.CreateDocument / OpenDocument) sin pedir permisos
 * de almacenamiento.
 */
object ExportImportManager {

    private val FORMATO_CSV_FECHA = DateTimeFormatter.ofPattern("dd/MM/yyyy")

    fun exportarCsv(records: List<AttendanceRecord>, out: OutputStream) {
        out.bufferedWriter().use { writer ->
            writer.write("Fecha,Día,Estado,Hora")
            writer.newLine()
            records.sortedBy { it.fecha }.forEach { r ->
                val fechaFmt = DateUtils.fromIso(r.fecha).format(FORMATO_CSV_FECHA)
                writer.write("$fechaFmt,${r.diaSemana},${r.estado},${r.horaRegistro}")
                writer.newLine()
            }
        }
    }

    fun exportarJson(records: List<AttendanceRecord>, out: OutputStream) {
        val arr = JSONArray()
        records.sortedBy { it.fecha }.forEach { r ->
            val obj = JSONObject()
            obj.put("fecha", r.fecha)
            obj.put("diaSemana", r.diaSemana)
            obj.put("estado", r.estado)
            obj.put("horaRegistro", r.horaRegistro)
            obj.put("fechaHoraTimestamp", r.fechaHoraTimestamp)
            obj.put("periodoId", r.periodoId)
            arr.put(obj)
        }
        out.bufferedWriter().use { it.write(arr.toString(2)) }
    }

    fun importarCsv(input: InputStream): List<AttendanceRecord> {
        val lines = input.bufferedReader().readLines()
        if (lines.isEmpty()) return emptyList()
        val body = if (lines.first().startsWith("Fecha")) lines.drop(1) else lines
        return body.mapNotNull { line ->
            val parts = line.split(",").map { it.trim() }
            if (parts.size < 4) return@mapNotNull null
            val (fechaStr, dia, estado, hora) = parts
            val fecha = runCatching {
                java.time.LocalDate.parse(fechaStr, FORMATO_CSV_FECHA)
            }.getOrNull() ?: return@mapNotNull null
            AttendanceRecord(
                fecha = DateUtils.toIso(fecha),
                diaSemana = dia,
                estado = estado,
                horaRegistro = hora,
                fechaHoraTimestamp = System.currentTimeMillis(),
                periodoId = ""
            )
        }
    }

    fun importarJson(input: InputStream): List<AttendanceRecord> {
        val text = input.bufferedReader().readText()
        val arr = JSONArray(text)
        val list = mutableListOf<AttendanceRecord>()
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            list.add(
                AttendanceRecord(
                    fecha = obj.getString("fecha"),
                    diaSemana = obj.optString("diaSemana"),
                    estado = obj.getString("estado"),
                    horaRegistro = obj.optString("horaRegistro"),
                    fechaHoraTimestamp = obj.optLong("fechaHoraTimestamp", System.currentTimeMillis()),
                    periodoId = obj.optString("periodoId")
                )
            )
        }
        return list
    }
}
