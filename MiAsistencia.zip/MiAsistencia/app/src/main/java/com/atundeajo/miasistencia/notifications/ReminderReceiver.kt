package com.atundeajo.miasistencia.notifications

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.atundeajo.miasistencia.data.AppDatabase
import com.atundeajo.miasistencia.data.AttendanceRepository
import com.atundeajo.miasistencia.data.UserPreferencesRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.LocalDate

class ReminderReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val reminderNumber = intent.getIntExtra(ReminderConstants.EXTRA_REMINDER_NUMBER, 1)
        val pendingResult = goAsync()

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val repo = AttendanceRepository(AppDatabase.getInstance(context).attendanceDao())
                val prefsRepo = UserPreferencesRepository(context)
                val settings = prefsRepo.current()

                val yaRegistrado = repo.getByDate(LocalDate.now()) != null

                if (!yaRegistrado) {
                    val debeMostrar = reminderNumber == 1 || settings.reminderRepeatIfUnregistered
                    if (debeMostrar) {
                        NotificationHelper.mostrarRecordatorio(context)
                    }
                }

                // Reprograma este recordatorio para el próximo día válido.
                val hora = if (reminderNumber == 1) settings.reminder1Hour else settings.reminder2Hour
                val minuto = if (reminderNumber == 1) settings.reminder1Minute else settings.reminder2Minute
                if (settings.remindersEnabled && (reminderNumber == 1 || settings.secondReminderEnabled)) {
                    ReminderScheduler.scheduleNext(context, reminderNumber, hora, minuto, settings.reminderDays)
                }
            } finally {
                pendingResult.finish()
            }
        }
    }
}
