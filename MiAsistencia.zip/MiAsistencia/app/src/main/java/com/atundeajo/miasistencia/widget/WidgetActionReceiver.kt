package com.atundeajo.miasistencia.widget

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.atundeajo.miasistencia.data.AppDatabase
import com.atundeajo.miasistencia.data.AttendanceRepository
import com.atundeajo.miasistencia.data.UserPreferencesRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.LocalDate

/** Registra V o X directamente desde los botones del widget de pantalla de inicio. */
class WidgetActionReceiver : BroadcastReceiver() {

    companion object {
        const val ACTION_REGISTRAR = "com.atundeajo.miasistencia.widget.action.REGISTRAR"
        const val EXTRA_ESTADO = "extra_estado"
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != ACTION_REGISTRAR) return
        val estado = intent.getStringExtra(EXTRA_ESTADO) ?: return
        val pendingResult = goAsync()

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val repo = AttendanceRepository(AppDatabase.getInstance(context).attendanceDao())
                val prefsRepo = UserPreferencesRepository(context)
                repo.registrar(LocalDate.now(), estado, prefsRepo.current().periodMode)
                WidgetUpdateUtil.updateAll(context)
            } finally {
                pendingResult.finish()
            }
        }
    }
}
