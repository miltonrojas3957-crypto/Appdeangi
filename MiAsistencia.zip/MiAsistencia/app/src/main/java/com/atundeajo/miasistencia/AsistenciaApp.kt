package com.atundeajo.miasistencia

import android.app.Application
import com.atundeajo.miasistencia.notifications.ReminderScheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class AsistenciaApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Reprograma los recordatorios al iniciar la app (por si cambiaron
        // los ajustes o el sistema los perdió, además del BootReceiver).
        CoroutineScope(Dispatchers.IO).launch {
            val prefs = com.atundeajo.miasistencia.data.UserPreferencesRepository(this@AsistenciaApp)
            ReminderScheduler.scheduleAll(this@AsistenciaApp, prefs.current())
        }
    }
}
