package com.atundeajo.miasistencia.ui.settings

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.atundeajo.miasistencia.data.AppDatabase
import com.atundeajo.miasistencia.data.AppSettings
import com.atundeajo.miasistencia.data.AttendanceRepository
import com.atundeajo.miasistencia.data.BackupManager
import com.atundeajo.miasistencia.data.ExportImportManager
import com.atundeajo.miasistencia.data.PersonalizationTheme
import com.atundeajo.miasistencia.data.ThemeMode
import com.atundeajo.miasistencia.data.UserPreferencesRepository
import com.atundeajo.miasistencia.domain.PeriodMode
import com.atundeajo.miasistencia.notifications.ReminderScheduler
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(application: Application) : AndroidViewModel(application) {

    private val prefsRepo = UserPreferencesRepository(application)
    private val repo = AttendanceRepository(AppDatabase.getInstance(application).attendanceDao())
    private val backupManager = BackupManager(repo, prefsRepo)

    val settings: StateFlow<AppSettings> = prefsRepo.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppSettings())

    private fun rescheduleReminders() {
        viewModelScope.launch {
            ReminderScheduler.scheduleAll(getApplication(), prefsRepo.current())
        }
    }

    fun setThemeMode(mode: ThemeMode) = viewModelScope.launch { prefsRepo.setThemeMode(mode) }
    fun setPeriodMode(mode: PeriodMode) = viewModelScope.launch { prefsRepo.setPeriodMode(mode) }
    fun setAllowEditPast(v: Boolean) = viewModelScope.launch { prefsRepo.setAllowEditPast(v) }
    fun setAllowFutureRecords(v: Boolean) = viewModelScope.launch { prefsRepo.setAllowFutureRecords(v) }
    fun setConfirmBeforeEdit(v: Boolean) = viewModelScope.launch { prefsRepo.setConfirmBeforeEdit(v) }
    fun setConfirmBeforeDelete(v: Boolean) = viewModelScope.launch { prefsRepo.setConfirmBeforeDelete(v) }

    fun setRemindersEnabled(v: Boolean) = viewModelScope.launch {
        prefsRepo.setRemindersEnabled(v)
        rescheduleReminders()
    }
    fun setReminder1Time(hour: Int, minute: Int) = viewModelScope.launch {
        prefsRepo.setReminder1Time(hour, minute)
        rescheduleReminders()
    }
    fun setReminderDays(days: Set<Int>) = viewModelScope.launch {
        prefsRepo.setReminderDays(days)
        rescheduleReminders()
    }
    fun setSecondReminderEnabled(v: Boolean) = viewModelScope.launch {
        prefsRepo.setSecondReminderEnabled(v)
        rescheduleReminders()
    }
    fun setReminder2Time(hour: Int, minute: Int) = viewModelScope.launch {
        prefsRepo.setReminder2Time(hour, minute)
        rescheduleReminders()
    }
    fun setReminderRepeat(v: Boolean) = viewModelScope.launch { prefsRepo.setReminderRepeat(v) }

    fun setWidgetShowStats(v: Boolean) = viewModelScope.launch { prefsRepo.setWidgetShowStats(v) }
    fun setWidgetShowDate(v: Boolean) = viewModelScope.launch { prefsRepo.setWidgetShowDate(v) }
    fun setWidgetShowDino(v: Boolean) = viewModelScope.launch { prefsRepo.setWidgetShowDino(v) }
    fun setWidgetShowFlowers(v: Boolean) = viewModelScope.launch { prefsRepo.setWidgetShowFlowers(v) }
    fun setWidgetShowQuickButtons(v: Boolean) = viewModelScope.launch { prefsRepo.setWidgetShowQuickButtons(v) }

    fun setPersonalizationTheme(theme: PersonalizationTheme) = viewModelScope.launch { prefsRepo.setPersonalizationTheme(theme) }
    fun setReduceAnimations(v: Boolean) = viewModelScope.launch { prefsRepo.setReduceAnimations(v) }

    fun exportarCsv(uri: Uri) = viewModelScope.launch {
        val records = repo.getAllOnce()
        getApplication<android.app.Application>().contentResolver.openOutputStream(uri)?.use { out ->
            ExportImportManager.exportarCsv(records, out)
        }
    }

    fun exportarJson(uri: Uri) = viewModelScope.launch {
        val records = repo.getAllOnce()
        getApplication<android.app.Application>().contentResolver.openOutputStream(uri)?.use { out ->
            ExportImportManager.exportarJson(records, out)
        }
    }

    fun importarCsv(uri: Uri) = viewModelScope.launch {
        getApplication<android.app.Application>().contentResolver.openInputStream(uri)?.use { input ->
            val records = ExportImportManager.importarCsv(input)
            records.forEach { repo.registrar(com.atundeajo.miasistencia.domain.DateUtils.fromIso(it.fecha), it.estado, settings.value.periodMode, it.horaRegistro) }
        }
    }

    fun importarJson(uri: Uri) = viewModelScope.launch {
        getApplication<android.app.Application>().contentResolver.openInputStream(uri)?.use { input ->
            val records = ExportImportManager.importarJson(input)
            records.forEach { repo.registrar(com.atundeajo.miasistencia.domain.DateUtils.fromIso(it.fecha), it.estado, settings.value.periodMode, it.horaRegistro) }
        }
    }

    fun crearBackup(uri: Uri) = viewModelScope.launch {
        getApplication<android.app.Application>().contentResolver.openOutputStream(uri)?.use { out ->
            backupManager.crearBackup(out)
        }
    }

    fun restaurarBackup(uri: Uri) = viewModelScope.launch {
        getApplication<android.app.Application>().contentResolver.openInputStream(uri)?.use { input ->
            backupManager.restaurarBackup(input)
        }
        rescheduleReminders()
    }

    fun eliminarTodo() = viewModelScope.launch {
        repo.borrarTodo()
    }
}
