package com.atundeajo.miasistencia.ui.calendar

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.atundeajo.miasistencia.data.AppSettings
import com.atundeajo.miasistencia.data.AttendanceRecord
import com.atundeajo.miasistencia.domain.DateUtils
import com.atundeajo.miasistencia.ui.components.ConfirmDialog
import java.time.LocalDate

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DayDetailSheet(
    date: LocalDate,
    record: AttendanceRecord?,
    settings: AppSettings,
    onChangeEstado: (LocalDate, String) -> Unit,
    onDelete: (LocalDate) -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState()
    var accionPendiente by remember { mutableStateOf<String?>(null) } // "V", "X" o "DELETE"

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        Column(modifier = Modifier
            .fillMaxWidth()
            .padding(24.dp)) {
            Text(DateUtils.formatoFechaLarga(date), style = MaterialTheme.typography.titleLarge)

            Text(
                when (record?.estado) {
                    AttendanceRecord.ESTADO_V -> "Estado: ✓ Asistió"
                    AttendanceRecord.ESTADO_X -> "Estado: ✕ No asistió"
                    else -> "Estado: sin registrar"
                },
                style = MaterialTheme.typography.bodyLarge,
                modifier = Modifier.padding(top = 8.dp)
            )
            if (record != null) {
                Text(
                    "Hora de registro: ${record.horaRegistro}",
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            Column(modifier = Modifier.padding(top = 20.dp)) {
                Button(
                    onClick = {
                        if (settings.confirmBeforeEdit && record != null) accionPendiente = AttendanceRecord.ESTADO_V
                        else onChangeEstado(date, AttendanceRecord.ESTADO_V)
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Cambiar a V") }

                OutlinedButton(
                    onClick = {
                        if (settings.confirmBeforeEdit && record != null) accionPendiente = AttendanceRecord.ESTADO_X
                        else onChangeEstado(date, AttendanceRecord.ESTADO_X)
                    },
                    modifier = Modifier.fillMaxWidth().padding(top = 10.dp)
                ) { Text("Cambiar a X") }

                if (record != null) {
                    TextButton(
                        onClick = {
                            if (settings.confirmBeforeDelete) accionPendiente = "DELETE"
                            else onDelete(date)
                        },
                        modifier = Modifier.fillMaxWidth().padding(top = 10.dp)
                    ) { Text("Eliminar registro") }
                }
            }
        }
    }

    if (accionPendiente != null) {
        val esEliminar = accionPendiente == "DELETE"
        ConfirmDialog(
            titulo = if (esEliminar) "Eliminar registro" else "Modificar registro",
            mensaje = if (esEliminar) "¿Seguro que deseas eliminar el registro de este día?"
                      else "¿Deseas cambiar el estado de este día?",
            textoConfirmar = if (esEliminar) "Eliminar" else "Cambiar",
            onConfirm = {
                if (esEliminar) onDelete(date) else onChangeEstado(date, accionPendiente!!)
                accionPendiente = null
            },
            onDismiss = { accionPendiente = null }
        )
    }
}
