package com.atundeajo.miasistencia.notifications

object ReminderConstants {
    const val CHANNEL_ID = "recordatorios_asistencia"
    const val NOTIFICATION_ID = 5001

    const val EXTRA_REMINDER_NUMBER = "extra_reminder_number" // 1 o 2
    const val EXTRA_ESTADO = "extra_estado" // "V" o "X"

    const val ACTION_SHOW_REMINDER = "com.atundeajo.miasistencia.action.SHOW_REMINDER"
    const val ACTION_REGISTER_FROM_NOTIFICATION = "com.atundeajo.miasistencia.action.REGISTER_FROM_NOTIFICATION"

    const val REQUEST_CODE_REMINDER_1 = 9001
    const val REQUEST_CODE_REMINDER_2 = 9002
}
