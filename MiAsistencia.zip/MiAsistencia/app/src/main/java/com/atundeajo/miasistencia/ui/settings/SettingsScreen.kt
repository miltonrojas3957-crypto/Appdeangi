package com.atundeajo.miasistencia.ui.settings

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.atundeajo.miasistencia.data.ThemeMode
import com.atundeajo.miasistencia.domain.PeriodMode
import com.atundeajo.miasistencia.ui.components.ConfirmDialog

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel = viewModel(),
    onAbrirPersonalizacion: () -> Unit
) {
    val settings by viewModel.settings.collectAsState()
    var mostrarConfirmEliminarTodo by remember { mutableStateOf(false) }
    var editandoHora by remember { mutableStateOf<Int?>(null) } // 1 o 2

    val csvExportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        uri?.let { viewModel.exportarCsv(it) }
    }
    val jsonExportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        uri?.let { viewModel.exportarJson(it) }
    }
    val csvImportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { viewModel.importarCsv(it) }
    }
    val jsonImportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { viewModel.importarJson(it) }
    }
    val backupLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        uri?.let { viewModel.crearBackup(it) }
    }
    val restoreLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { viewModel.restaurarBackup(it) }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
    ) {
        Text("Ajustes", style = MaterialTheme.typography.headlineMedium)

        SeccionCard("General") {
            Text("Tema", style = MaterialTheme.typography.titleMedium)
            SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
                ThemeMode.entries.forEachIndexed { index, mode ->
                    SegmentedButton(
                        selected = settings.themeMode == mode,
                        onClick = { viewModel.setThemeMode(mode) },
                        shape = SegmentedButtonDefaults.itemShape(index = index, count = ThemeMode.entries.size)
                    ) {
                        Text(
                            when (mode) {
                                ThemeMode.LIGHT -> "Claro"
                                ThemeMode.DARK -> "Oscuro"
                                ThemeMode.SYSTEM -> "Sistema"
                            }
                        )
                    }
                }
            }
            TextButton(onClick = onAbrirPersonalizacion, modifier = Modifier.padding(top = 8.dp)) {
                Text("🎨 Personalización visual")
            }
        }

        SeccionCard("Registro") {
            Text("Modo de período", style = MaterialTheme.typography.titleMedium)
            SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
                PeriodMode.entries.forEachIndexed { index, mode ->
                    SegmentedButton(
                        selected = settings.periodMode == mode,
                        onClick = { viewModel.setPeriodMode(mode) },
                        shape = SegmentedButtonDefaults.itemShape(index = index, count = PeriodMode.entries.size)
                    ) {
                        Text(if (mode == PeriodMode.CALENDAR_MONTH) "Mes calendario" else "Ciclo personalizado")
                    }
                }
            }
            SwitchRow("Permitir modificar registros anteriores", settings.allowEditPast) { viewModel.setAllowEditPast(it) }
            SwitchRow("Permitir registros futuros", settings.allowFutureRecords) { viewModel.setAllowFutureRecords(it) }
            SwitchRow("Confirmación antes de modificar", settings.confirmBeforeEdit) { viewModel.setConfirmBeforeEdit(it) }
            SwitchRow("Confirmación antes de eliminar", settings.confirmBeforeDelete) { viewModel.setConfirmBeforeDelete(it) }
        }

        SeccionCard("Recordatorios") {
            SwitchRow("Activar recordatorios", settings.remindersEnabled) { viewModel.setRemindersEnabled(it) }
            if (settings.remindersEnabled) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Hora del recordatorio")
                    TextButton(onClick = { editandoHora = 1 }) {
                        Text("%02d:%02d".format(settings.reminder1Hour, settings.reminder1Minute))
                    }
                }
                Text("Días", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 8.dp))
                DiasSemanaSelector(settings.reminderDays) { viewModel.setReminderDays(it) }

                SwitchRow("Segundo recordatorio si no respondiste", settings.secondReminderEnabled) { viewModel.setSecondReminderEnabled(it) }
                if (settings.secondReminderEnabled) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Hora del segundo recordatorio")
                        TextButton(onClick = { editandoHora = 2 }) {
                            Text("%02d:%02d".format(settings.reminder2Hour, settings.reminder2Minute))
                        }
                    }
                }
                SwitchRow("Repetir si aún no registraste el día", settings.reminderRepeatIfUnregistered) { viewModel.setReminderRepeat(it) }
            }
        }

        SeccionCard("Widget") {
            SwitchRow("Mostrar estadísticas", settings.widgetShowStats) { viewModel.setWidgetShowStats(it) }
            SwitchRow("Mostrar fecha", settings.widgetShowDate) { viewModel.setWidgetShowDate(it) }
            SwitchRow("Mostrar dinosaurio", settings.widgetShowDino) { viewModel.setWidgetShowDino(it) }
            SwitchRow("Mostrar flores", settings.widgetShowFlowers) { viewModel.setWidgetShowFlowers(it) }
            SwitchRow("Mostrar botones rápidos", settings.widgetShowQuickButtons) { viewModel.setWidgetShowQuickButtons(it) }
        }

        SeccionCard("Datos") {
            Text("Exportar", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                OutlinedButton(onClick = { csvExportLauncher.launch("mi_asistencia.csv") }) { Text("CSV") }
                OutlinedButton(onClick = { jsonExportLauncher.launch("mi_asistencia.json") }) { Text("JSON") }
            }
            Text("Importar", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                OutlinedButton(onClick = { csvImportLauncher.launch(arrayOf("text/*")) }) { Text("CSV") }
                OutlinedButton(onClick = { jsonImportLauncher.launch(arrayOf("application/json")) }) { Text("JSON") }
            }
            Text("Copia de seguridad", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                OutlinedButton(onClick = { backupLauncher.launch("backup_mi_asistencia.json") }) { Text("Crear copia") }
                OutlinedButton(onClick = { restoreLauncher.launch(arrayOf("application/json")) }) { Text("Restaurar") }
            }
            Button(
                onClick = { mostrarConfirmEliminarTodo = true },
                colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                modifier = Modifier.padding(top = 20.dp)
            ) { Text("Eliminar todos los datos") }
        }
    }

    if (mostrarConfirmEliminarTodo) {
        ConfirmDialog(
            titulo = "Eliminar todos los datos",
            mensaje = "Esta acción borrará permanentemente todos tus registros. ¿Deseas continuar?",
            textoConfirmar = "Eliminar todo",
            onConfirm = { viewModel.eliminarTodo(); mostrarConfirmEliminarTodo = false },
            onDismiss = { mostrarConfirmEliminarTodo = false }
        )
    }

    if (editandoHora != null) {
        val esPrimero = editandoHora == 1
        val horaInicial = if (esPrimero) settings.reminder1Hour else settings.reminder2Hour
        val minutoInicial = if (esPrimero) settings.reminder1Minute else settings.reminder2Minute
        val timeState = rememberTimePickerState(initialHour = horaInicial, initialMinute = minutoInicial, is24Hour = true)
        Dialog(onDismissRequest = { editandoHora = null }, properties = DialogProperties()) {
            Card(shape = MaterialTheme.shapes.large) {
                Column(modifier = Modifier.padding(20.dp)) {
                    TimePicker(state = timeState)
                    Row(modifier = Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = { editandoHora = null }) { Text("Cancelar") }
                        TextButton(onClick = {
                            if (esPrimero) viewModel.setReminder1Time(timeState.hour, timeState.minute)
                            else viewModel.setReminder2Time(timeState.hour, timeState.minute)
                            editandoHora = null
                        }) { Text("Aceptar") }
                    }
                }
            }
        }
    }
}

@Composable
private fun SeccionCard(titulo: String, contenido: @Composable () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(titulo, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
            Column(modifier = Modifier.padding(top = 12.dp)) {
                contenido()
            }
        }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, modifier = Modifier.padding(end = 8.dp))
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun DiasSemanaSelector(diasSeleccionados: Set<Int>, onChange: (Set<Int>) -> Unit) {
    val etiquetas = listOf("L" to 1, "M" to 2, "X" to 3, "J" to 4, "V" to 5, "S" to 6, "D" to 7)
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 4.dp)) {
        etiquetas.forEach { (etiqueta, dia) ->
            val seleccionado = diasSeleccionados.contains(dia)
            FilterChip(
                selected = seleccionado,
                onClick = {
                    onChange(if (seleccionado) diasSeleccionados - dia else diasSeleccionados + dia)
                },
                label = { Text(etiqueta) }
            )
        }
    }
}
