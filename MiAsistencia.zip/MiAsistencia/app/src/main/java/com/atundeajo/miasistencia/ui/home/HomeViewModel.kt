package com.atundeajo.miasistencia.ui.home

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.atundeajo.miasistencia.data.AppDatabase
import com.atundeajo.miasistencia.data.AppSettings
import com.atundeajo.miasistencia.data.AttendanceRecord
import com.atundeajo.miasistencia.data.AttendanceRepository
import com.atundeajo.miasistencia.data.UserPreferencesRepository
import com.atundeajo.miasistencia.domain.PeriodCalculator
import com.atundeajo.miasistencia.domain.PeriodStats
import com.atundeajo.miasistencia.domain.StatsCalculator
import com.atundeajo.miasistencia.widget.WidgetUpdateUtil
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate

class HomeViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = AttendanceRepository(AppDatabase.getInstance(application).attendanceDao())
    private val prefsRepo = UserPreferencesRepository(application)

    private val today: LocalDate = LocalDate.now()

    val settings: StateFlow<AppSettings> = prefsRepo.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppSettings())

    private val _todayRecord = MutableStateFlow<AttendanceRecord?>(null)
    val todayRecord: StateFlow<AttendanceRecord?> = _todayRecord

    private val _periodStats = MutableStateFlow(PeriodStats(0, 0, 0, 0, 0.0))
    val periodStats: StateFlow<PeriodStats> = _periodStats

    private val _pendingConfirmEstado = MutableStateFlow<String?>(null)
    val pendingConfirmEstado: StateFlow<String?> = _pendingConfirmEstado

    init {
        viewModelScope.launch {
            _todayRecord.value = repo.getByDate(today)
            refreshStats()
        }
    }

    private suspend fun refreshStats() {
        val mode = settings.value.periodMode
        val anchor = repo.getFirstRecordDate()?.dayOfMonth
        val range = PeriodCalculator.periodContaining(mode, today, anchor)
        val records = repo.getRange(range.start, range.end)
        _periodStats.value = StatsCalculator.calcular(range, records)
    }

    fun onQuickRegister(estado: String) {
        val existing = _todayRecord.value
        if (existing == null) {
            confirmRegister(estado)
        } else if (existing.estado != estado) {
            _pendingConfirmEstado.value = estado
        }
    }

    fun confirmRegister(estado: String) {
        viewModelScope.launch {
            val record = repo.registrar(today, estado, settings.value.periodMode)
            _todayRecord.value = record
            refreshStats()
            WidgetUpdateUtil.updateAll(getApplication())
            _pendingConfirmEstado.value = null
        }
    }

    fun cancelConfirm() {
        _pendingConfirmEstado.value = null
    }

    fun hoy(): LocalDate = today
}
