package com.atundeajo.miasistencia.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.atundeajo.miasistencia.MainActivity
import com.atundeajo.miasistencia.R
import com.atundeajo.miasistencia.data.AppDatabase
import com.atundeajo.miasistencia.data.AttendanceRecord
import com.atundeajo.miasistencia.data.AttendanceRepository
import com.atundeajo.miasistencia.data.UserPreferencesRepository
import com.atundeajo.miasistencia.domain.DateUtils
import com.atundeajo.miasistencia.domain.PeriodCalculator
import com.atundeajo.miasistencia.domain.StatsCalculator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.LocalDate

class LargeAttendanceWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                appWidgetIds.forEach { id -> actualizarWidget(context, appWidgetManager, id) }
            } finally {
                pending.finish()
            }
        }
    }

    companion object {
        suspend fun actualizarWidget(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int) {
            val repo = AttendanceRepository(AppDatabase.getInstance(context).attendanceDao())
            val prefsRepo = UserPreferencesRepository(context)
            val settings = prefsRepo.current()
            val hoy = LocalDate.now()
            val registro = repo.getByDate(hoy)

            val anchor = repo.getFirstRecordDate()?.dayOfMonth
            val periodo = PeriodCalculator.periodContaining(settings.periodMode, hoy, anchor)
            val registros = repo.getRange(periodo.start, periodo.end)
            val stats = StatsCalculator.calcular(periodo, registros)

            val views = RemoteViews(context.packageName, R.layout.widget_large)
            views.setTextViewText(
                R.id.tvMes,
                "${DateUtils.nombreMesTitulo(periodo.start.monthValue)} ${periodo.start.year}"
            )
            views.setTextViewText(R.id.tvTrabajados, "Trabajados: ${stats.trabajados}")
            views.setTextViewText(R.id.tvNoAsistidos, "No asistidos: ${stats.noAsistidos}")
            views.setTextViewText(R.id.tvFecha, DateUtils.formatoFechaCorta(hoy))
            views.setTextViewText(
                R.id.tvEstado,
                when (registro?.estado) {
                    AttendanceRecord.ESTADO_V -> "¡Trabajaste! 🌷"
                    AttendanceRecord.ESTADO_X -> "Día registrado"
                    else -> "¿Trabajaste hoy?"
                }
            )

            views.setOnClickPendingIntent(R.id.btnSi, accionPendingIntent(context, "V", 2001))
            views.setOnClickPendingIntent(R.id.btnNo, accionPendingIntent(context, "X", 2002))

            val abrirAppIntent = PendingIntent.getActivity(
                context, 2003, Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widgetRoot, abrirAppIntent)

            appWidgetManager.updateAppWidget(appWidgetId, views)
        }

        private fun accionPendingIntent(context: Context, estado: String, requestCode: Int): PendingIntent {
            val intent = Intent(context, WidgetActionReceiver::class.java).apply {
                action = WidgetActionReceiver.ACTION_REGISTRAR
                putExtra(WidgetActionReceiver.EXTRA_ESTADO, estado)
            }
            return PendingIntent.getBroadcast(
                context, requestCode, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }
    }
}
