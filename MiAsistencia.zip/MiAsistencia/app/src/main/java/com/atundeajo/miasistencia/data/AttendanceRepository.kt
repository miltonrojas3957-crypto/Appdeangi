package com.atundeajo.miasistencia.data

import com.atundeajo.miasistencia.domain.DateUtils
import com.atundeajo.miasistencia.domain.PeriodCalculator
import com.atundeajo.miasistencia.domain.PeriodMode
import kotlinx.coroutines.flow.Flow
import java.time.LocalDate

class AttendanceRepository(private val dao: AttendanceDao) {

    fun observeAll(): Flow<List<AttendanceRecord>> = dao.observeAll()

    fun observeRange(start: LocalDate, end: LocalDate): Flow<List<AttendanceRecord>> =
        dao.observeRange(DateUtils.toIso(start), DateUtils.toIso(end))

    suspend fun getByDate(date: LocalDate): AttendanceRecord? =
        dao.getByDate(DateUtils.toIso(date))

    suspend fun getRange(start: LocalDate, end: LocalDate): List<AttendanceRecord> =
        dao.getRange(DateUtils.toIso(start), DateUtils.toIso(end))

    suspend fun getAllOnce(): List<AttendanceRecord> = dao.getAllOnce()

    suspend fun getFirstRecordDate(): LocalDate? =
        dao.getFirstRecordDate()?.let { DateUtils.fromIso(it) }

    /** Registra o actualiza el estado de un día. Calcula el período correspondiente. */
    suspend fun registrar(
        date: LocalDate,
        estado: String,
        mode: PeriodMode,
        hora: String = DateUtils.horaActual()
    ): AttendanceRecord {
        val anchor = getFirstRecordDate()?.dayOfMonth
        val period = PeriodCalculator.periodContaining(mode, date, anchor)
        val record = AttendanceRecord(
            fecha = DateUtils.toIso(date),
            diaSemana = DateUtils.nombreDia(date),
            estado = estado,
            horaRegistro = hora,
            fechaHoraTimestamp = System.currentTimeMillis(),
            periodoId = period.id
        )
        dao.upsert(record)
        return record
    }

    suspend fun eliminar(date: LocalDate) = dao.deleteByDate(DateUtils.toIso(date))

    suspend fun borrarTodo() = dao.deleteAll()

    suspend fun restaurar(records: List<AttendanceRecord>) {
        dao.deleteAll()
        dao.upsertAll(records)
    }
}
