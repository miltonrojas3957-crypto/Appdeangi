package com.atundeajo.miasistencia.ui.calendar

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material3.IconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.atundeajo.miasistencia.domain.DateUtils
import com.atundeajo.miasistencia.ui.theme.estadoColors
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth

@Composable
fun CalendarScreen(viewModel: CalendarViewModel = viewModel()) {
    val yearMonth by viewModel.yearMonth.collectAsState()
    val recordsByDate by viewModel.recordsByDate.collectAsState()
    val selectedDate by viewModel.selectedDate.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val colors = estadoColors(settings.themeMode)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(onClick = { viewModel.prevMonth() }) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Mes anterior")
            }
            Text(
                "${DateUtils.nombreMesTitulo(yearMonth.monthValue)} ${yearMonth.year}",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.SemiBold
            )
            IconButton(onClick = { viewModel.nextMonth() }) {
                Icon(Icons.Default.ArrowForward, contentDescription = "Mes siguiente")
            }
        }

        Row(modifier = Modifier.fillMaxWidth().padding(top = 12.dp)) {
            listOf("Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom").forEach { d ->
                Text(
                    d,
                    modifier = Modifier.weight(1f),
                    style = MaterialTheme.typography.labelLarge,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }
        }

        val semanas = buildCalendarGrid(yearMonth)
        val hoy = LocalDate.now()

        semanas.forEach { semana ->
            Row(modifier = Modifier.fillMaxWidth().padding(top = 6.dp)) {
                semana.forEach { date ->
                    com.atundeajo.miasistencia.ui.components.DayCell(
                        date = date,
                        record = recordsByDate[date],
                        isToday = date == hoy,
                        isCurrentMonth = date.month == yearMonth.month,
                        colorAsistio = colors.asistio,
                        colorNoAsistio = colors.noAsistio,
                        colorSinRegistrar = colors.sinRegistrar,
                        onClick = { viewModel.selectDate(date) },
                        modifier = Modifier.weight(1f).size(44.dp).padding(2.dp)
                    )
                }
            }
        }
    }

    if (selectedDate != null) {
        DayDetailSheet(
            date = selectedDate!!,
            record = recordsByDate[selectedDate],
            settings = settings,
            onChangeEstado = { date, estado -> viewModel.setEstado(date, estado) },
            onDelete = { date -> viewModel.eliminar(date) },
            onDismiss = { viewModel.dismissDetail() }
        )
    }
}

/** Genera las semanas (lunes a domingo) necesarias para cubrir el mes completo,
 *  incluyendo días del mes anterior/siguiente para rellenar la cuadrícula. */
private fun buildCalendarGrid(yearMonth: YearMonth): List<List<LocalDate>> {
    val firstOfMonth = yearMonth.atDay(1)
    val startOffset = firstOfMonth.dayOfWeek.value - DayOfWeek.MONDAY.value
    val gridStart = firstOfMonth.minusDays(startOffset.toLong())

    val totalCells = 42 // 6 semanas fijas, suficiente para cualquier mes
    val days = (0 until totalCells).map { gridStart.plusDays(it.toLong()) }
    return days.chunked(7)
}
