package com.atundeajo.miasistencia.ui.components

import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable

@Composable
fun ConfirmDialog(
    titulo: String,
    mensaje: String,
    textoConfirmar: String = "Cambiar",
    textoCancelar: String = "Cancelar",
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(titulo) },
        text = { Text(mensaje) },
        confirmButton = {
            TextButton(onClick = onConfirm) { Text(textoConfirmar) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(textoCancelar) }
        }
    )
}
