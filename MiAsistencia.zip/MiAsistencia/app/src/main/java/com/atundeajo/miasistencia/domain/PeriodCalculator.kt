package com.atundeajo.miasistencia.domain

import java.time.LocalDate

enum class PeriodMode { CALENDAR_MONTH, CUSTOM_CYCLE }

data class PeriodRange(
    val start: LocalDate,
    val end: LocalDate,
    val id: String
)

/**
 * Calcula el período (rango de fechas) al que pertenece una fecha dada,
 * según el modo elegido en configuración.
 *
 * - CALENDAR_MONTH: del día 1 al último día del mes calendario.
 * - CUSTOM_CYCLE: ciclo de 1 mes que comienza el mismo día del mes del
 *   primer registro histórico del usuario (el "ancla").
 */
object PeriodCalculator {

    fun periodContaining(mode: PeriodMode, date: LocalDate, anchorDay: Int?): PeriodRange {
        return when (mode) {
            PeriodMode.CALENDAR_MONTH -> {
                val start = date.withDayOfMonth(1)
                val end = date.withDayOfMonth(date.lengthOfMonth())
                PeriodRange(start, end, idFor(start))
            }
            PeriodMode.CUSTOM_CYCLE -> {
                val anchor = anchorDay ?: date.dayOfMonth
                var start = safeWithDay(date, anchor)
                if (start.isAfter(date)) {
                    start = safeWithDay(date.minusMonths(1), anchor)
                }
                val end = safeWithDay(start.plusMonths(1), anchor).minusDays(1)
                PeriodRange(start, end, idFor(start))
            }
        }
    }

    fun idFor(start: LocalDate): String = "P-$start"

    private fun safeWithDay(date: LocalDate, day: Int): LocalDate {
        val d = minOf(day, date.lengthOfMonth())
        return date.withDayOfMonth(d)
    }
}
