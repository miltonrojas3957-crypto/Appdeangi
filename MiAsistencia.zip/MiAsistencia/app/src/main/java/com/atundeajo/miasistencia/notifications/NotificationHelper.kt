package com.atundeajo.miasistencia.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.atundeajo.miasistencia.MainActivity
import com.atundeajo.miasistencia.R

object NotificationHelper {

    fun crearCanal(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val canal = NotificationChannel(
                ReminderConstants.CHANNEL_ID,
                "Recordatorios de asistencia",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Recordatorio diario para registrar si trabajaste hoy"
            }
            val manager = context.getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(canal)
        }
    }

    fun mostrarRecordatorio(context: Context) {
        crearCanal(context)

        val contentIntent = PendingIntent.getActivity(
            context, 0,
            Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val siIntent = Intent(context, NotificationActionReceiver::class.java).apply {
            action = ReminderConstants.ACTION_REGISTER_FROM_NOTIFICATION
            putExtra(ReminderConstants.EXTRA_ESTADO, "V")
        }
        val siPending = PendingIntent.getBroadcast(
            context, 1, siIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val noIntent = Intent(context, NotificationActionReceiver::class.java).apply {
            action = ReminderConstants.ACTION_REGISTER_FROM_NOTIFICATION
            putExtra(ReminderConstants.EXTRA_ESTADO, "X")
        }
        val noPending = PendingIntent.getBroadcast(
            context, 2, noIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, ReminderConstants.CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("¿Trabajaste hoy? 🌷")
            .setContentText("Toca para registrar tu asistencia de hoy")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(contentIntent)
            .addAction(0, "✓ SÍ", siPending)
            .addAction(0, "✕ NO", noPending)
            .build()

        NotificationManagerCompat.from(context).notify(ReminderConstants.NOTIFICATION_ID, notification)
    }

    fun cancelar(context: Context) {
        NotificationManagerCompat.from(context).cancel(ReminderConstants.NOTIFICATION_ID)
    }
}
