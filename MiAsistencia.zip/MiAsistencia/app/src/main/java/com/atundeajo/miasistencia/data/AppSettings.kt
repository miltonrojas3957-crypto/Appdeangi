package com.atundeajo.miasistencia.data

import com.atundeajo.miasistencia.domain.PeriodMode

enum class ThemeMode { LIGHT, DARK, SYSTEM }

enum class PersonalizationTheme(val etiqueta: String, val emoji: String) {
    JARDIN_PASTEL("Jardín pastel", "🌷"),
    NUBECITAS("Nubecitas", "☁️"),
    DINO_CHUBBY("Dino Chubby", "🦕"),
    FLORAL("Floral", "🌸"),
    MINIMALISTA("Minimalista", "✨")
}

data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val periodMode: PeriodMode = PeriodMode.CALENDAR_MONTH,
    val allowEditPast: Boolean = true,
    val allowFutureRecords: Boolean = true,
    val confirmBeforeEdit: Boolean = true,
    val confirmBeforeDelete: Boolean = true,

    val remindersEnabled: Boolean = false,
    val reminder1Hour: Int = 21,
    val reminder1Minute: Int = 0,
    val reminderDays: Set<Int> = setOf(1, 2, 3, 4, 5, 6, 7), // 1=Lunes ... 7=Domingo

    val secondReminderEnabled: Boolean = false,
    val reminder2Hour: Int = 21,
    val reminder2Minute: Int = 30,
    val reminderRepeatIfUnregistered: Boolean = true,

    val widgetShowStats: Boolean = true,
    val widgetShowDate: Boolean = true,
    val widgetShowDino: Boolean = true,
    val widgetShowFlowers: Boolean = true,
    val widgetShowQuickButtons: Boolean = true,

    val personalizationTheme: PersonalizationTheme = PersonalizationTheme.JARDIN_PASTEL,
    val reduceAnimations: Boolean = false
)
