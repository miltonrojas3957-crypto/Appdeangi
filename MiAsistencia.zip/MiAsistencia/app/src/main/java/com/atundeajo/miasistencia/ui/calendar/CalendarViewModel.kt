package com.atundeajo.miasistencia.ui.calendar

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.atundeajo.miasistencia.data.AppDatabase
import com.atundeajo.miasistencia.data.AppSettings
import com.atundeajo.miasistencia.data.AttendanceRecord
import com.atundeajo.miasistencia.data.AttendanceRepository
import com.atundeajo.miasistencia.data.UserPreferencesRepository
import com.atundeajo.miasistencia.domain.DateUtils
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.YearMonth

@OptIn(ExperimentalCoroutinesApi::class)
class CalendarViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = AttendanceRepository(AppDatabase.getInstance(application).attendanceDao())
    private val prefsRepo = UserPreferencesRepository(application)

    val settings: StateFlow<AppSettings> = prefsRepo.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppSettings())

    private val _yearMonth = MutableStateFlow(YearMonth.now())
    val yearMonth: StateFlow<YearMonth> = _yearMonth

    val recordsByDate: StateFlow<Map<LocalDate, AttendanceRecord>> = _yearMonth
        .flatMapLatest { ym -> repo.observeRange(ym.atDay(1), ym.atEndOfMonth()) }
        .map { list -> list.associateBy { DateUtils.fromIso(it.fecha) } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    private val _selectedDate = MutableStateFlow<LocalDate?>(null)
    val selectedDate: StateFlow<LocalDate?> = _selectedDate

    fun nextMonth() { _yearMonth.value = _yearMonth.value.plusMonths(1) }
    fun prevMonth() { _yearMonth.value = _yearMonth.value.minusMonths(1) }

    fun selectDate(date: LocalDate) { _selectedDate.value = date }
    fun dismissDetail() { _selectedDate.value = null }

    fun setEstado(date: LocalDate, estado: String) {
        viewModelScope.launch {
            repo.registrar(date, estado, settings.value.periodMode)
            com.atundeajo.miasistencia.widget.WidgetUpdateUtil.updateAll(getApplication())
        }
    }

    fun eliminar(date: LocalDate) {
        viewModelScope.launch {
            repo.eliminar(date)
            com.atundeajo.miasistencia.widget.WidgetUpdateUtil.updateAll(getApplication())
            dismissDetail()
        }
    }
}
