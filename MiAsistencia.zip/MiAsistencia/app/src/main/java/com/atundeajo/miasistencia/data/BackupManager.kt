package com.atundeajo.miasistencia.data

import org.json.JSONArray
import org.json.JSONObject
import java.io.InputStream
import java.io.OutputStream

/**
 * Copia de seguridad completa: todos los registros + configuración relevante,
 * en un único archivo JSON portable.
 */
class BackupManager(
    private val repository: AttendanceRepository,
    private val preferencesRepository: UserPreferencesRepository
) {

    suspend fun crearBackup(out: OutputStream) {
        val records = repository.getAllOnce()
        val settings = preferencesRepository.current()

        val root = JSONObject()
        root.put("version", 1)

        val recordsArr = JSONArray()
        records.forEach { r ->
            val obj = JSONObject()
            obj.put("fecha", r.fecha)
            obj.put("diaSemana", r.diaSemana)
            obj.put("estado", r.estado)
            obj.put("horaRegistro", r.horaRegistro)
            obj.put("fechaHoraTimestamp", r.fechaHoraTimestamp)
            obj.put("periodoId", r.periodoId)
            recordsArr.put(obj)
        }
        root.put("records", recordsArr)

        val settingsObj = JSONObject()
        settingsObj.put("themeMode", settings.themeMode.name)
        settingsObj.put("periodMode", settings.periodMode.name)
        settingsObj.put("remindersEnabled", settings.remindersEnabled)
        settingsObj.put("reminder1Hour", settings.reminder1Hour)
        settingsObj.put("reminder1Minute", settings.reminder1Minute)
        settingsObj.put("personalizationTheme", settings.personalizationTheme.name)
        root.put("settings", settingsObj)

        out.bufferedWriter().use { it.write(root.toString(2)) }
    }

    suspend fun restaurarBackup(input: InputStream) {
        val text = input.bufferedReader().readText()
        val root = JSONObject(text)

        val recordsArr = root.optJSONArray("records") ?: JSONArray()
        val records = mutableListOf<AttendanceRecord>()
        for (i in 0 until recordsArr.length()) {
            val obj = recordsArr.getJSONObject(i)
            records.add(
                AttendanceRecord(
                    fecha = obj.getString("fecha"),
                    diaSemana = obj.optString("diaSemana"),
                    estado = obj.getString("estado"),
                    horaRegistro = obj.optString("horaRegistro"),
                    fechaHoraTimestamp = obj.optLong("fechaHoraTimestamp", System.currentTimeMillis()),
                    periodoId = obj.optString("periodoId")
                )
            )
        }
        repository.restaurar(records)

        val settingsObj = root.optJSONObject("settings")
        if (settingsObj != null) {
            val map = mutableMapOf<String, Any?>()
            settingsObj.keys().forEach { key -> map[key] = settingsObj.get(key) }
            preferencesRepository.restoreRaw(map)
        }
    }
}
