package com.atundeajo.miasistencia.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.atundeajo.miasistencia.domain.PeriodStats
import kotlin.math.roundToInt

@Composable
fun StatsSummaryCard(
    stats: PeriodStats,
    modifier: Modifier = Modifier,
    titulo: String = "Este período"
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text(titulo, style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                StatItem("${Emojis.FLOR} Trabajados", stats.trabajados.toString())
                StatItem("${Emojis.NUBE} No asistidos", stats.noAsistidos.toString())
                StatItem("○ Sin registrar", stats.sinRegistrar.toString())
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                "${Emojis.GRAFICO} Asistencia: ${formatearPorcentaje(stats.porcentaje)}%",
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
private fun StatItem(label: String, value: String) {
    Column {
        Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text(label, style = MaterialTheme.typography.bodyMedium)
    }
}

fun formatearPorcentaje(valor: Double): String {
    val redondeado = (valor * 10).roundToInt() / 10.0
    return if (redondeado == redondeado.toInt().toDouble()) {
        redondeado.toInt().toString()
    } else {
        redondeado.toString().replace(".", ",")
    }
}
