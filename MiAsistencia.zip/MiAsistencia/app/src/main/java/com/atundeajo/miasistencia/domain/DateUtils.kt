package com.atundeajo.miasistencia.domain

import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter

object DateUtils {
    private val DIAS = listOf(
        "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"
    )
    private val MESES = listOf(
        "enero", "febrero", "marzo", "abril", "mayo", "junio",
        "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"
    )
    private val MESES_TITULO = listOf(
        "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
        "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"
    )

    fun nombreDia(date: LocalDate): String = DIAS[date.dayOfWeek.value - 1]
    fun nombreDiaCorto(date: LocalDate): String = nombreDia(date).take(3)
    fun nombreMes(month: Int): String = MESES[month - 1]
    fun nombreMesTitulo(month: Int): String = MESES_TITULO[month - 1]

    fun formatoFechaLarga(date: LocalDate): String =
        "${nombreDia(date)} ${date.dayOfMonth} de ${nombreMes(date.monthValue)} de ${date.year}"

    fun formatoFechaCorta(date: LocalDate): String =
        "${nombreDia(date)} ${date.dayOfMonth} de ${nombreMes(date.monthValue)}"

    fun toIso(date: LocalDate): String = date.toString()
    fun fromIso(s: String): LocalDate = LocalDate.parse(s)

    fun horaActual(): String = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"))

    fun saludoSegunHora(hora: Int): String = when (hora) {
        in 5..11 -> "Buenos días"
        in 12..18 -> "Buenas tardes"
        else -> "Buenas noches"
    }
}
