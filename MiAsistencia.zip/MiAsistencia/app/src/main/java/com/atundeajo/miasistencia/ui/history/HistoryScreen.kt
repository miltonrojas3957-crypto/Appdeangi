package com.atundeajo.miasistencia.ui.history

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.atundeajo.miasistencia.domain.DateUtils
import com.atundeajo.miasistencia.ui.components.formatearPorcentaje

@Composable
fun HistoryScreen(viewModel: HistoryViewModel = viewModel()) {
    val periodos by viewModel.periodosFiltrados.collectAsState()
    val anios by viewModel.aniosDisponibles.collectAsState()
    val filtroAnio by viewModel.filtroAnio.collectAsState()
    val filtroMes by viewModel.filtroMes.collectAsState()
    val filtroEstado by viewModel.filtroEstado.collectAsState()

    val expandido = remember { mutableStateMapOf<String, Boolean>() }

    Column(modifier = Modifier.fillMaxSize().padding(20.dp)) {
        Text("Historial", style = MaterialTheme.typography.headlineMedium)

        Row(modifier = Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            AnioDropdown(anios, filtroAnio) { viewModel.setFiltroAnio(it) }
            MesDropdown(filtroMes) { viewModel.setFiltroMes(it) }
        }

        Row(modifier = Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = filtroEstado == null, onClick = { viewModel.setFiltroEstado(null) }, label = { Text("Todos") })
            FilterChip(selected = filtroEstado == "V", onClick = { viewModel.setFiltroEstado("V") }, label = { Text("Asistió") })
            FilterChip(selected = filtroEstado == "X", onClick = { viewModel.setFiltroEstado("X") }, label = { Text("No asistió") })
        }

        if (periodos.isEmpty()) {
            Text(
                "Todavía no hay períodos para mostrar.",
                modifier = Modifier.padding(top = 24.dp),
                style = MaterialTheme.typography.bodyLarge
            )
        }

        LazyColumn(modifier = Modifier.padding(top = 12.dp)) {
            items(periodos, key = { it.range.id }) { periodo ->
                val abierto = expandido[periodo.range.id] ?: false
                Card(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                    shape = MaterialTheme.shapes.large,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    onClick = { expandido[periodo.range.id] = !abierto }
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            "${DateUtils.nombreMesTitulo(periodo.range.start.monthValue)} ${periodo.range.start.year}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            "Trabajados: ${periodo.stats.trabajados}  ·  No asistidos: ${periodo.stats.noAsistidos}  ·  ${formatearPorcentaje(periodo.stats.porcentaje)}%",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        if (abierto) {
                            Column(modifier = Modifier.padding(top = 12.dp)) {
                                periodo.records.forEach { r ->
                                    val fecha = DateUtils.fromIso(r.fecha)
                                    Row(
                                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(DateUtils.formatoFechaCorta(fecha), style = MaterialTheme.typography.bodyMedium)
                                        Text(
                                            if (r.estado == "V") "✓ Asistió · ${r.horaRegistro}" else "✕ No asistió · ${r.horaRegistro}",
                                            style = MaterialTheme.typography.bodyMedium
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AnioDropdown(anios: List<Int>, seleccionado: Int?, onSelect: (Int?) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    AssistChip(onClick = { expanded = true }, label = { Text(seleccionado?.toString() ?: "Año") })
    DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
        DropdownMenuItem(text = { Text("Todos") }, onClick = { onSelect(null); expanded = false })
        anios.forEach { anio ->
            DropdownMenuItem(text = { Text(anio.toString()) }, onClick = { onSelect(anio); expanded = false })
        }
    }
}

@Composable
private fun MesDropdown(seleccionado: Int?, onSelect: (Int?) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    AssistChip(onClick = { expanded = true }, label = { Text(seleccionado?.let { DateUtils.nombreMesTitulo(it) } ?: "Mes") })
    DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
        DropdownMenuItem(text = { Text("Todos") }, onClick = { onSelect(null); expanded = false })
        (1..12).forEach { mes ->
            DropdownMenuItem(text = { Text(DateUtils.nombreMesTitulo(mes)) }, onClick = { onSelect(mes); expanded = false })
        }
    }
}
