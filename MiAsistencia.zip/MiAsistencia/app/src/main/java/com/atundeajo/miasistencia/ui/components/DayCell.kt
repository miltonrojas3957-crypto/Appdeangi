package com.atundeajo.miasistencia.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.atundeajo.miasistencia.data.AttendanceRecord
import java.time.LocalDate

@Composable
fun DayCell(
    date: LocalDate,
    record: AttendanceRecord?,
    isToday: Boolean,
    isCurrentMonth: Boolean,
    colorAsistio: Color,
    colorNoAsistio: Color,
    colorSinRegistrar: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val bg = when (record?.estado) {
        AttendanceRecord.ESTADO_V -> colorAsistio
        AttendanceRecord.ESTADO_X -> colorNoAsistio
        else -> colorSinRegistrar
    }
    val alpha = if (isCurrentMonth) 1f else 0.35f

    Box(
        modifier = modifier
            .aspectRatio(1f)
            .background(bg.copy(alpha = alpha), MaterialTheme.shapes.medium)
            .then(
                if (isToday) Modifier.border(2.dp, MaterialTheme.colorScheme.primary, MaterialTheme.shapes.medium)
                else Modifier
            )
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                date.dayOfMonth.toString(),
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = if (isToday) FontWeight.Bold else FontWeight.Normal
            )
            when (record?.estado) {
                AttendanceRecord.ESTADO_V -> Text(Emojis.CHECK, style = MaterialTheme.typography.bodyMedium)
                AttendanceRecord.ESTADO_X -> Text(Emojis.CRUZ, style = MaterialTheme.typography.bodyMedium)
                else -> Text("·", style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}
