package com.atundeajo.miasistencia.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Emojis usados como elementos decorativos en toda la app (mismos que en la
 *  especificación original): flores, nubes, estrellas y el dino chubby. */
object Emojis {
    const val DINO = "🦕"
    const val DINO_DURMIENDO = "😴"
    const val FLOR = "🌷"
    const val FLOR2 = "🌸"
    const val NUBE = "☁️"
    const val ESTRELLA = "✨"
    const val FIESTA = "🎉"
    const val GRAFICO = "📊"
    const val CORAZON = "💗"
    const val CHECK = "✓"
    const val CRUZ = "✕"
}

/** Insignia circular pastel con un emoji centrado — el "sticker" base de toda
 *  la decoración de la app (dino, flor, nube, etc). */
@Composable
fun EmojiBadge(
    emoji: String,
    modifier: Modifier = Modifier,
    background: Color = MaterialTheme.colorScheme.surfaceVariant,
    size: Dp = 56.dp,
    emojiSize: Dp = 28.dp
) {
    Box(
        modifier = modifier
            .size(size)
            .background(background, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Text(text = emoji, fontSize = (emojiSize.value * 0.9).sp)
    }
}

/** Pequeño "blob" de color suave, usado como decoración discreta en esquinas
 *  de tarjetas y pantallas sin interferir con el contenido principal. */
@Composable
fun SoftBlob(
    color: Color,
    modifier: Modifier = Modifier,
    size: Dp = 40.dp
) {
    Box(
        modifier = modifier
            .size(size)
            .background(color.copy(alpha = 0.55f), CircleShape)
    )
}
