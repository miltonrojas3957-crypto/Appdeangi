package com.atundeajo.miasistencia.notifications

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.atundeajo.miasistencia.data.AppSettings
import java.time.DayOfWeek
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId

/**
 * Programa las alarmas de recordatorio usando AlarmManager. Cada alarma se
 * reprograma a sí misma para el siguiente día válido dentro de ReminderReceiver,
 * ya que AlarmManager no soporta repeticiones semanales nativas de forma precisa.
 */
object ReminderScheduler {

    fun scheduleAll(context: Context, settings: AppSettings) {
        cancel(context, ReminderConstants.REQUEST_CODE_REMINDER_1)
        cancel(context, ReminderConstants.REQUEST_CODE_REMINDER_2)

        if (!settings.remindersEnabled) return

        scheduleNext(context, 1, settings.reminder1Hour, settings.reminder1Minute, settings.reminderDays)

        if (settings.secondReminderEnabled) {
            scheduleNext(context, 2, settings.reminder2Hour, settings.reminder2Minute, settings.reminderDays)
        }
    }

    fun scheduleNext(context: Context, reminderNumber: Int, hour: Int, minute: Int, allowedDays: Set<Int>) {
        if (allowedDays.isEmpty()) return

        val now = LocalDateTime.now()
        var candidate = now.toLocalDate().atTime(LocalTime.of(hour, minute))
        if (!candidate.isAfter(now)) {
            candidate = candidate.plusDays(1)
        }
        // Avanza hasta el próximo día permitido (máximo 7 iteraciones)
        var intentos = 0
        while (!allowedDays.contains(candidate.dayOfWeek.value) && intentos < 8) {
            candidate = candidate.plusDays(1)
            intentos++
        }

        val triggerAtMillis = candidate.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()

        val requestCode = if (reminderNumber == 1) ReminderConstants.REQUEST_CODE_REMINDER_1 else ReminderConstants.REQUEST_CODE_REMINDER_2

        val intent = Intent(context, ReminderReceiver::class.java).apply {
            action = ReminderConstants.ACTION_SHOW_REMINDER
            putExtra(ReminderConstants.EXTRA_REMINDER_NUMBER, reminderNumber)
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context, requestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        trySetExact(alarmManager, triggerAtMillis, pendingIntent)
    }

    private fun trySetExact(alarmManager: AlarmManager, triggerAtMillis: Long, pendingIntent: PendingIntent) {
        val puedeExacta = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || alarmManager.canScheduleExactAlarms()
        if (puedeExacta) {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pendingIntent)
        } else {
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pendingIntent)
        }
    }

    private fun cancel(context: Context, requestCode: Int) {
        val intent = Intent(context, ReminderReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context, requestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarmManager.cancel(pendingIntent)
    }
}
