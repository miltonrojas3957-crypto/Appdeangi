package com.atundeajo.miasistencia.ui.history

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.atundeajo.miasistencia.data.AppDatabase
import com.atundeajo.miasistencia.data.AppSettings
import com.atundeajo.miasistencia.data.AttendanceRecord
import com.atundeajo.miasistencia.data.AttendanceRepository
import com.atundeajo.miasistencia.data.UserPreferencesRepository
import com.atundeajo.miasistencia.domain.DateUtils
import com.atundeajo.miasistencia.domain.PeriodCalculator
import com.atundeajo.miasistencia.domain.PeriodRange
import com.atundeajo.miasistencia.domain.PeriodStats
import com.atundeajo.miasistencia.domain.StatsCalculator
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

data class PeriodSummary(
    val range: PeriodRange,
    val stats: PeriodStats,
    val records: List<AttendanceRecord>
)

class HistoryViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = AttendanceRepository(AppDatabase.getInstance(application).attendanceDao())
    private val prefsRepo = UserPreferencesRepository(application)

    val settings: StateFlow<AppSettings> = prefsRepo.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppSettings())

    val filtroAnio = MutableStateFlow<Int?>(null)
    val filtroMes = MutableStateFlow<Int?>(null)
    val filtroEstado = MutableStateFlow<String?>(null) // "V", "X" o null (todos)

    private val allPeriods: StateFlow<List<PeriodSummary>> =
        combine(repo.observeAll(), settings) { records, s -> agrupar(records, s) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val periodosFiltrados: StateFlow<List<PeriodSummary>> =
        combine(allPeriods, filtroAnio, filtroMes, filtroEstado) { periods, anio, mes, estado ->
            periods
                .filter { anio == null || it.range.start.year == anio }
                .filter { mes == null || it.range.start.monthValue == mes }
                .map { summary ->
                    if (estado == null) summary
                    else summary.copy(records = summary.records.filter { it.estado == estado })
                }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val aniosDisponibles: StateFlow<List<Int>> = allPeriods
        .map { periods -> periods.map { it.range.start.year }.distinct().sortedDescending() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private fun agrupar(records: List<AttendanceRecord>, settings: AppSettings): List<PeriodSummary> {
        if (records.isEmpty()) return emptyList()
        val anchor = DateUtils.fromIso(records.minOf { it.fecha }).dayOfMonth
        val grouped = records.groupBy { r ->
            PeriodCalculator.periodContaining(settings.periodMode, DateUtils.fromIso(r.fecha), anchor)
        }
        return grouped.entries.map { (range, recs) ->
            val ordenados = recs.sortedBy { it.fecha }
            PeriodSummary(range, StatsCalculator.calcular(range, ordenados), ordenados)
        }.sortedByDescending { it.range.start }
    }

    fun setFiltroAnio(anio: Int?) { filtroAnio.value = anio }
    fun setFiltroMes(mes: Int?) { filtroMes.value = mes }
    fun setFiltroEstado(estado: String?) { filtroEstado.value = estado }
}
