package com.atundeajo.miasistencia.widget

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent

object WidgetUpdateUtil {

    fun updateAll(context: Context) {
        actualizarProveedor(context, CompactAttendanceWidgetProvider::class.java)
        actualizarProveedor(context, LargeAttendanceWidgetProvider::class.java)
    }

    private fun actualizarProveedor(context: Context, clase: Class<*>) {
        val manager = AppWidgetManager.getInstance(context)
        val ids = manager.getAppWidgetIds(ComponentName(context, clase))
        if (ids.isEmpty()) return
        val intent = Intent(context, clase).apply {
            action = AppWidgetManager.ACTION_APPWIDGET_UPDATE
            putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
        }
        context.sendBroadcast(intent)
    }
}
