package com.atundeajo.miasistencia.data

import android.content.Context
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.atundeajo.miasistencia.domain.PeriodMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "settings")

private object Keys {
    val THEME_MODE = stringPreferencesKey("theme_mode")
    val PERIOD_MODE = stringPreferencesKey("period_mode")
    val ALLOW_EDIT_PAST = booleanPreferencesKey("allow_edit_past")
    val ALLOW_FUTURE = booleanPreferencesKey("allow_future_records")
    val CONFIRM_EDIT = booleanPreferencesKey("confirm_before_edit")
    val CONFIRM_DELETE = booleanPreferencesKey("confirm_before_delete")

    val REMINDERS_ENABLED = booleanPreferencesKey("reminders_enabled")
    val REMINDER1_HOUR = intPreferencesKey("reminder1_hour")
    val REMINDER1_MINUTE = intPreferencesKey("reminder1_minute")
    val REMINDER_DAYS = stringSetPreferencesKey("reminder_days")

    val SECOND_REMINDER_ENABLED = booleanPreferencesKey("second_reminder_enabled")
    val REMINDER2_HOUR = intPreferencesKey("reminder2_hour")
    val REMINDER2_MINUTE = intPreferencesKey("reminder2_minute")
    val REMINDER_REPEAT = booleanPreferencesKey("reminder_repeat_if_unregistered")

    val WIDGET_SHOW_STATS = booleanPreferencesKey("widget_show_stats")
    val WIDGET_SHOW_DATE = booleanPreferencesKey("widget_show_date")
    val WIDGET_SHOW_DINO = booleanPreferencesKey("widget_show_dino")
    val WIDGET_SHOW_FLOWERS = booleanPreferencesKey("widget_show_flowers")
    val WIDGET_SHOW_QUICK_BUTTONS = booleanPreferencesKey("widget_show_quick_buttons")

    val PERSONALIZATION_THEME = stringPreferencesKey("personalization_theme")
    val REDUCE_ANIMATIONS = booleanPreferencesKey("reduce_animations")
}

class UserPreferencesRepository(private val context: Context) {

    val settingsFlow: Flow<AppSettings> = context.dataStore.data.map { prefs -> prefs.toAppSettings() }

    suspend fun current(): AppSettings = settingsFlow.first()

    private fun Preferences.toAppSettings(): AppSettings {
        val defaults = AppSettings()
        return AppSettings(
            themeMode = this[Keys.THEME_MODE]?.let { runCatching { ThemeMode.valueOf(it) }.getOrNull() } ?: defaults.themeMode,
            periodMode = this[Keys.PERIOD_MODE]?.let { runCatching { PeriodMode.valueOf(it) }.getOrNull() } ?: defaults.periodMode,
            allowEditPast = this[Keys.ALLOW_EDIT_PAST] ?: defaults.allowEditPast,
            allowFutureRecords = this[Keys.ALLOW_FUTURE] ?: defaults.allowFutureRecords,
            confirmBeforeEdit = this[Keys.CONFIRM_EDIT] ?: defaults.confirmBeforeEdit,
            confirmBeforeDelete = this[Keys.CONFIRM_DELETE] ?: defaults.confirmBeforeDelete,
            remindersEnabled = this[Keys.REMINDERS_ENABLED] ?: defaults.remindersEnabled,
            reminder1Hour = this[Keys.REMINDER1_HOUR] ?: defaults.reminder1Hour,
            reminder1Minute = this[Keys.REMINDER1_MINUTE] ?: defaults.reminder1Minute,
            reminderDays = this[Keys.REMINDER_DAYS]?.map { it.toInt() }?.toSet() ?: defaults.reminderDays,
            secondReminderEnabled = this[Keys.SECOND_REMINDER_ENABLED] ?: defaults.secondReminderEnabled,
            reminder2Hour = this[Keys.REMINDER2_HOUR] ?: defaults.reminder2Hour,
            reminder2Minute = this[Keys.REMINDER2_MINUTE] ?: defaults.reminder2Minute,
            reminderRepeatIfUnregistered = this[Keys.REMINDER_REPEAT] ?: defaults.reminderRepeatIfUnregistered,
            widgetShowStats = this[Keys.WIDGET_SHOW_STATS] ?: defaults.widgetShowStats,
            widgetShowDate = this[Keys.WIDGET_SHOW_DATE] ?: defaults.widgetShowDate,
            widgetShowDino = this[Keys.WIDGET_SHOW_DINO] ?: defaults.widgetShowDino,
            widgetShowFlowers = this[Keys.WIDGET_SHOW_FLOWERS] ?: defaults.widgetShowFlowers,
            widgetShowQuickButtons = this[Keys.WIDGET_SHOW_QUICK_BUTTONS] ?: defaults.widgetShowQuickButtons,
            personalizationTheme = this[Keys.PERSONALIZATION_THEME]?.let { runCatching { PersonalizationTheme.valueOf(it) }.getOrNull() } ?: defaults.personalizationTheme,
            reduceAnimations = this[Keys.REDUCE_ANIMATIONS] ?: defaults.reduceAnimations
        )
    }

    private suspend fun update(block: (MutablePreferences) -> Unit) {
        context.dataStore.edit { block(it) }
    }

    suspend fun setThemeMode(mode: ThemeMode) = update { it[Keys.THEME_MODE] = mode.name }
    suspend fun setPeriodMode(mode: PeriodMode) = update { it[Keys.PERIOD_MODE] = mode.name }
    suspend fun setAllowEditPast(value: Boolean) = update { it[Keys.ALLOW_EDIT_PAST] = value }
    suspend fun setAllowFutureRecords(value: Boolean) = update { it[Keys.ALLOW_FUTURE] = value }
    suspend fun setConfirmBeforeEdit(value: Boolean) = update { it[Keys.CONFIRM_EDIT] = value }
    suspend fun setConfirmBeforeDelete(value: Boolean) = update { it[Keys.CONFIRM_DELETE] = value }

    suspend fun setRemindersEnabled(value: Boolean) = update { it[Keys.REMINDERS_ENABLED] = value }
    suspend fun setReminder1Time(hour: Int, minute: Int) = update {
        it[Keys.REMINDER1_HOUR] = hour; it[Keys.REMINDER1_MINUTE] = minute
    }
    suspend fun setReminderDays(days: Set<Int>) = update {
        it[Keys.REMINDER_DAYS] = days.map { d -> d.toString() }.toSet()
    }
    suspend fun setSecondReminderEnabled(value: Boolean) = update { it[Keys.SECOND_REMINDER_ENABLED] = value }
    suspend fun setReminder2Time(hour: Int, minute: Int) = update {
        it[Keys.REMINDER2_HOUR] = hour; it[Keys.REMINDER2_MINUTE] = minute
    }
    suspend fun setReminderRepeat(value: Boolean) = update { it[Keys.REMINDER_REPEAT] = value }

    suspend fun setWidgetShowStats(value: Boolean) = update { it[Keys.WIDGET_SHOW_STATS] = value }
    suspend fun setWidgetShowDate(value: Boolean) = update { it[Keys.WIDGET_SHOW_DATE] = value }
    suspend fun setWidgetShowDino(value: Boolean) = update { it[Keys.WIDGET_SHOW_DINO] = value }
    suspend fun setWidgetShowFlowers(value: Boolean) = update { it[Keys.WIDGET_SHOW_FLOWERS] = value }
    suspend fun setWidgetShowQuickButtons(value: Boolean) = update { it[Keys.WIDGET_SHOW_QUICK_BUTTONS] = value }

    suspend fun setPersonalizationTheme(theme: PersonalizationTheme) = update { it[Keys.PERSONALIZATION_THEME] = theme.name }
    suspend fun setReduceAnimations(value: Boolean) = update { it[Keys.REDUCE_ANIMATIONS] = value }

    suspend fun restoreRaw(map: Map<String, Any?>) = update { prefs ->
        (map["themeMode"] as? String)?.let { prefs[Keys.THEME_MODE] = it }
        (map["periodMode"] as? String)?.let { prefs[Keys.PERIOD_MODE] = it }
        (map["remindersEnabled"] as? Boolean)?.let { prefs[Keys.REMINDERS_ENABLED] = it }
        (map["reminder1Hour"] as? Int)?.let { prefs[Keys.REMINDER1_HOUR] = it }
        (map["reminder1Minute"] as? Int)?.let { prefs[Keys.REMINDER1_MINUTE] = it }
        (map["personalizationTheme"] as? String)?.let { prefs[Keys.PERSONALIZATION_THEME] = it }
    }
}
