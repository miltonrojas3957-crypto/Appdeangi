package com.atundeajo.miasistencia.notifications

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.atundeajo.miasistencia.data.AppDatabase
import com.atundeajo.miasistencia.data.AttendanceRepository
import com.atundeajo.miasistencia.data.UserPreferencesRepository
import com.atundeajo.miasistencia.widget.WidgetUpdateUtil
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.LocalDate

/** Registra V o X directamente desde los botones de acción de la notificación. */
class NotificationActionReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val estado = intent.getStringExtra(ReminderConstants.EXTRA_ESTADO) ?: return
        val pendingResult = goAsync()

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val repo = AttendanceRepository(AppDatabase.getInstance(context).attendanceDao())
                val prefsRepo = UserPreferencesRepository(context)
                repo.registrar(LocalDate.now(), estado, prefsRepo.current().periodMode)
                NotificationHelper.cancelar(context)
                WidgetUpdateUtil.updateAll(context)
            } finally {
                pendingResult.finish()
            }
        }
    }
}
