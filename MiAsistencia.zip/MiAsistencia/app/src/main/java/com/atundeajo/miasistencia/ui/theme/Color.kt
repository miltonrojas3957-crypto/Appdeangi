package com.atundeajo.miasistencia.ui.theme

import androidx.compose.ui.graphics.Color

// Paleta pastel — modo claro
val RosaPastel = Color(0xFFF7D6E0)
val CelestePastel = Color(0xFFD6EAF7)
val LilaPastel = Color(0xFFE6D9F7)
val Lavanda = Color(0xFFEDE4FB)
val AmarilloPastel = Color(0xFFFBF3C7)
val VerdeMenta = Color(0xFFD3F2E4)
val Crema = Color(0xFFFFF8EE)
val BlancoCalido = Color(0xFFFFFDF9)

// Estados — modo claro
val VerdeAsistioLight = Color(0xFFB9E6C9)
val RosaNoAsistioLight = Color(0xFFF6C6C6)
val GrisSinRegistrarLight = Color(0xFFECEAF5)

val TextoPrincipalLight = Color(0xFF4A4358)
val TextoSecundarioLight = Color(0xFF8B7F9E)

// Paleta — modo oscuro (tonos suaves, nunca negro puro)
val AzulNoche = Color(0xFF2B2A44)
val LavandaOscuro = Color(0xFF3B3355)
val GrisAzulado = Color(0xFF383A52)
val RosaOscuroSuave = Color(0xFF4A3350)

val VerdeAsistioDark = Color(0xFF3E6E58)
val RosaNoAsistioDark = Color(0xFF6E3E4A)
val GrisSinRegistrarDark = Color(0xFF454363)

val TextoPrincipalDark = Color(0xFFF1ECFB)
val TextoSecundarioDark = Color(0xFFC2B8DA)
