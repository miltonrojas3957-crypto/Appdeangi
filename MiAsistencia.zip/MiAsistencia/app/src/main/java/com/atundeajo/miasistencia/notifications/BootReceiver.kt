package com.atundeajo.miasistencia.notifications

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.atundeajo.miasistencia.data.UserPreferencesRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/** AlarmManager pierde las alarmas al reiniciar el dispositivo: las reprograma aquí. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val prefsRepo = UserPreferencesRepository(context)
                ReminderScheduler.scheduleAll(context, prefsRepo.current())
            } finally {
                pendingResult.finish()
            }
        }
    }
}
