package com.atundeajo.miasistencia.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.atundeajo.miasistencia.data.ThemeMode

private val LightColors = lightColorScheme(
    primary = Color(0xFF9B7FC9),
    onPrimary = Color.White,
    secondary = Color(0xFFE8A5C0),
    onSecondary = Color.White,
    tertiary = Color(0xFF7FBF9E),
    background = BlancoCalido,
    onBackground = TextoPrincipalLight,
    surface = Crema,
    onSurface = TextoPrincipalLight,
    surfaceVariant = Lavanda,
    onSurfaceVariant = TextoSecundarioLight,
    error = Color(0xFFD98A8A)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFC7B3EE),
    onPrimary = Color(0xFF2B2A44),
    secondary = Color(0xFFEFB9CF),
    onSecondary = Color(0xFF2B2A44),
    tertiary = Color(0xFFA6DFC2),
    background = AzulNoche,
    onBackground = TextoPrincipalDark,
    surface = LavandaOscuro,
    onSurface = TextoPrincipalDark,
    surfaceVariant = GrisAzulado,
    onSurfaceVariant = TextoSecundarioDark,
    error = Color(0xFFE2A0A0)
)

/** Colores de estado que no forman parte del ColorScheme de Material pero se
 *  usan en el calendario, el widget y las tarjetas de resumen. */
data class EstadoColors(
    val asistio: Color,
    val noAsistio: Color,
    val sinRegistrar: Color
)

val LocalEstadoColorsLight = EstadoColors(VerdeAsistioLight, RosaNoAsistioLight, GrisSinRegistrarLight)
val LocalEstadoColorsDark = EstadoColors(VerdeAsistioDark, RosaNoAsistioDark, GrisSinRegistrarDark)

@Composable
fun MiAsistenciaTheme(
    themeMode: ThemeMode = ThemeMode.SYSTEM,
    content: @Composable () -> Unit
) {
    val useDark = when (themeMode) {
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
    }
    val colors = if (useDark) DarkColors else LightColors

    MaterialTheme(
        colorScheme = colors,
        shapes = MiAsistenciaShapes,
        typography = MiAsistenciaTypography,
        content = content
    )
}

@Composable
fun estadoColors(themeMode: ThemeMode): EstadoColors {
    val useDark = when (themeMode) {
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
    }
    return if (useDark) LocalEstadoColorsDark else LocalEstadoColorsLight
}
